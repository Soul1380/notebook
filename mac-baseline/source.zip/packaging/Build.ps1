param(
  [Parameter(Mandatory=$true)][string]$NodePath,
  [Parameter(Mandatory=$true)][string]$StagePath,
  [Parameter(Mandatory=$true)][string]$InstallerPath
)
$ErrorActionPreference='Stop'
$project=Split-Path -Parent $PSScriptRoot
$compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if(!(Test-Path -LiteralPath $compiler)){throw 'C# compiler not found'}
if(!(Test-Path -LiteralPath $NodePath)){throw 'Node runtime not found'}
New-Item -ItemType Directory -Force -Path $StagePath | Out-Null
$sourceFiles=@('index.html','styles.css','app.js','preferences.js','colors.js','files.js','interaction.js','desktop.cjs','floating.ps1','tasks.ps1','window.ps1','README.md','notebook.ico','version.json')
$allowed=@($sourceFiles)+@('HandwritingNotebook.exe','HandwritingNotebookBackend.exe','Uninstall.exe','Updater.exe')
$unexpected=@(Get-ChildItem -LiteralPath $StagePath -Force | Where-Object { $_.Name -notin $allowed -or $_.PSIsContainer })
if($unexpected.Count -gt 0){throw 'Build stage contains unexpected files; choose an empty staging folder.'}
foreach($name in $sourceFiles){Copy-Item -LiteralPath (Join-Path $project $name) -Destination (Join-Path $StagePath $name) -Force}
Copy-Item -LiteralPath $NodePath -Destination (Join-Path $StagePath 'HandwritingNotebookBackend.exe') -Force
$icon=Join-Path $PSScriptRoot 'notebook.ico'
$launcher=Join-Path $StagePath 'HandwritingNotebook.exe'
& $compiler /nologo /target:winexe /platform:x64 /optimize+ /reference:System.Windows.Forms.dll /reference:System.Drawing.dll "/win32icon:$icon" "/out:$launcher" (Join-Path $PSScriptRoot 'Launcher.cs')
if($LASTEXITCODE -ne 0){throw 'Launcher compilation failed'}
& $compiler /nologo /target:winexe /platform:x64 /optimize+ /reference:System.Windows.Forms.dll /reference:System.Drawing.dll "/win32icon:$icon" "/out:$(Join-Path $StagePath 'Uninstall.exe')" (Join-Path $PSScriptRoot 'Uninstall.cs')
if($LASTEXITCODE -ne 0){throw 'Uninstaller compilation failed'}
& $compiler /nologo /target:winexe /platform:x64 /optimize+ /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.Management.dll /reference:System.Web.Extensions.dll /reference:System.IO.Compression.dll /reference:System.IO.Compression.FileSystem.dll "/win32icon:$icon" "/out:$(Join-Path $StagePath 'Updater.exe')" (Join-Path $PSScriptRoot 'Updater.cs')
if($LASTEXITCODE -ne 0){throw 'Updater compilation failed'}
# Embed the uninstaller in an existing script so versions with the old update allowlist can upgrade.
$uninstallBytes=[Convert]::ToBase64String([IO.File]::ReadAllBytes((Join-Path $StagePath 'Uninstall.exe')))
$bootstrap='$uninstaller=Join-Path $PSScriptRoot ''Uninstall.exe'';if(!(Test-Path -LiteralPath $uninstaller)){[IO.File]::WriteAllBytes($uninstaller,[Convert]::FromBase64String('''+$uninstallBytes+'''))}'
$ballPath=Join-Path $StagePath 'floating.ps1'
[IO.File]::WriteAllText($ballPath,$bootstrap+[Environment]::NewLine+[IO.File]::ReadAllText($ballPath),(New-Object Text.UTF8Encoding($true)))
Add-Type -AssemblyName System.IO.Compression.FileSystem
$payload=Join-Path (Split-Path -Parent $StagePath) 'NotebookPayload.zip'
if(Test-Path -LiteralPath $payload){Remove-Item -LiteralPath $payload -Force}
[System.IO.Compression.ZipFile]::CreateFromDirectory($StagePath,$payload,[System.IO.Compression.CompressionLevel]::Optimal,$false)
& $compiler /nologo /target:winexe /platform:x64 /optimize+ /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.IO.Compression.dll /reference:System.IO.Compression.FileSystem.dll "/win32icon:$icon" "/resource:$payload,NotebookPayload.zip" "/out:$InstallerPath" (Join-Path $PSScriptRoot 'Installer.cs')
if($LASTEXITCODE -ne 0){throw 'Installer compilation failed'}
$updatePath=Join-Path (Split-Path -Parent $InstallerPath) 'HandwritingNotebook-update.zip'
if(Test-Path -LiteralPath $updatePath){Remove-Item -LiteralPath $updatePath -Force}
$stream=[IO.File]::Open($updatePath,[IO.FileMode]::CreateNew)
try{$zip=New-Object IO.Compression.ZipArchive($stream,[IO.Compression.ZipArchiveMode]::Create,$false);try{foreach($name in @($sourceFiles)+@('HandwritingNotebook.exe','HandwritingNotebookBackend.exe')){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,(Join-Path $StagePath $name),$name,[IO.Compression.CompressionLevel]::Optimal)}}finally{$zip.Dispose()}}finally{$stream.Dispose()}
Get-Item -LiteralPath $InstallerPath | Select-Object FullName,Length
